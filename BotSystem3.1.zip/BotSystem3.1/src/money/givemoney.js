const Discord = require('discord.js')
const fs = require('fs')
const config = JSON.parse(fs.readFileSync('config.json', 'utf8'))
const allowed = JSON.parse(fs.readFileSync('allowed.json', 'utf8'))
const admin = JSON.parse(fs.readFileSync('admin.json', 'utf8'))

const COLORS = {
    red: 0xe74c3c,
    green: 0x2ecc71,
    yellow: 0x9ccc65
}

module.exports = {
    givemoney(msg) {
      var commandLength = config.prefix.length + 10
      var givelength = config.prefix.length + 7 + 26
		var msgLength = msg.content.length
		var showUser = msg.content.slice(commandLength, commandLength + 22)

		var giveuser = showUser.slice(2, showUser.length - 1)
		var allowed = JSON.parse(fs.readFileSync('allowed.json', 'utf8'))
        
      var amount = msg.content.slice(givelength, msgLength)
		
		if (giveuser.startsWith('!')) {
            giveuser = giveuser.slice(1, giveuser.length)
      }
      else {
          var amount = msg.content.slice(givelength - 1, msgLength)
      }
      if (giveuser.length > 18) {
			var giveuser = giveuser.slice(0, giveuser.length - 1)
		}
      
      try {
          var opendata = JSON.parse(fs.readFileSync(`./moneydata/money/${giveuser}.json`, 'utf8'))
          var money = opendata[giveuser]
      }
      catch(e) {
          fs.writeFileSync(`./moneydata/money/${giveuser}.json`, `{\n    \"${giveuser}\": 0\n}`)
          var opendata = JSON.parse(fs.readFileSync(`./moneydata/money/${giveuser}.json`, 'utf8'))
          var money = opendata[giveuser]
      }

      var money = parseInt(money)
      var amount = parseInt(amount)

      var newamount = money + amount
      var emb = new Discord.RichEmbed()
          .setColor(COLORS.yellow)

      if (msg.author.id in admin) {
          try {
              fs.writeFileSync(`./moneydata/money/${giveuser}.json`, `{\n    "${giveuser}": ${newamount}\n}`)
              emb.setTitle(`Cheat erfolgreich. Der benutzer hat nun ${newamount}${config.money}`)
              msg.channel.send('', emb)
              msg.delete()
          }
          catch(e) {
              emb.setTitle(`Fehler; Betrag konnte nicht gespeichert werden`)
              msg.channel.send('', emb)
              msg.delete()
          }

          try {
              fs.appendFileSync(`./moneydata/logs/givemoney.txt`, `${msg.author.username} hat ${amount}${config.money} an ${giveuser} gecheatet!`)
          }
          catch(e) {
              fs.writeFileSync(`./moneydata/logs/givemoney.txt`, `${msg.author.username} hat ${amount}${config.money} an ${giveuser} gecheatet!`)
          }
      }
      else {
          emb.setTitle(`Du hast keine Berechtigung, dies zu tun`)
          msg.channel.send('', emb)
          msg.delete()
      }
   }
}
