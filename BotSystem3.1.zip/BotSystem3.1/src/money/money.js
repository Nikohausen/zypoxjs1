const Discord = require('discord.js')
const fs = require('fs')
const config = JSON.parse(fs.readFileSync('config.json', 'utf8'))
const allowed = JSON.parse(fs.readFileSync('allowed.json', 'utf8'))

const COLORS = {
    red: 0xe74c3c,
    green: 0x2ecc71,
    yellow: 0x9ccc65
}

module.exports = {
	money(msg) {
		try {
			var opendata = JSON.parse(fs.readFileSync(`./moneydata/money/${msg.author.id}.json`))
			var money = opendata[msg.author.id]
		}
		catch(e) {
			var money = 0
		}
		var emb = new Discord.RichEmbed()
			.setColor(COLORS.yellow)
			.setTitle(`Du (${msg.author.username}) hast ${money}${config.money}!`)
		msg.delete()
		msg.channel.send('', emb)
	}
}
