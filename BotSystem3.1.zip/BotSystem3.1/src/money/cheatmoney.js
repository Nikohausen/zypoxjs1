const Discord = require('discord.js')
const fs = require('fs')
const config = JSON.parse(fs.readFileSync('config.json', 'utf8'))
const allowed = JSON.parse(fs.readFileSync('allowed.json', 'utf8'))
const admin = JSON.parse(fs.readFileSync('admin.json', 'utf8'))

const COLORS = {
    red: 0xe74c3c,
    green: 0x2ecc71,
    yellow: 0x9ccc65
}

module.exports = {
    cheatmoney(msg) {
        var giveuser = msg.author.id
        var commandLength = config.prefix.length + 11
        var cheatamount = msg.content.slice(commandLength, msg.content.length)
        var amount = msg.content.slice(commandLength, msg.content.length)
        try {
        	var oldamount = JSON.parse(fs.readFileSync(`./moneydata/money/${msg.author.id}.json`, 'utf8'))
        	var oldamount = parseInt(oldamount[msg.author.id])
        }
        catch(e) {
        	var oldamount = parseInt(0)
        }
        var emb = new Discord.RichEmbed()
            .setColor(COLORS.yellow)
        try {
            var cheatamount = parseInt(cheatamount)
        }
        catch(e) {
            emb.setTitle(`Bitte gib eine gültige Zahl an, ${msg.author.username}`)
        }
        var newamount = oldamount + cheatamount

        if (msg.author.id in admin) {
            try {
                fs.writeFileSync(`./moneydata/money/${giveuser}.json`, `{\n    "${giveuser}": ${newamount}\n}`)
                emb.setTitle(`Cheat erfolgreich. Du hast nun ${newamount}${config.money}`)
                msg.channel.send('', emb)
            }
            catch(e) {
                emb.setTitle(`Fehler; Betrag konnte nicht gespeichert werden`)
                msg.channel.send('', emb)

            }

            try {
                fs.appendFileSync(`./moneydata/logs/givemoney.txt`, `${msg.author.username} hat ${amount}${config.money} an ${giveuser} gecheatet!`)
            }
            catch(e) {
                fs.writeFileSync(`./moneydata/logs/givemoney.txt`, `${msg.author.username} hat ${amount}${config.money} an ${giveuser} gecheatet!`)
            }
        }
        else {
            emb.setTitle(`Du hast keine Berechtigung, dies zu tun`)
            msg.channel.send('', emb)
        }
    }
}
