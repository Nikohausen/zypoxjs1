const Discord = require('discord.js')
const fs = require('fs')
const config = JSON.parse(fs.readFileSync('config.json', 'utf8'))
const allowed = JSON.parse(fs.readFileSync('allowed.json', 'utf8'))

const COLORS = {
    red: 0xe74c3c,
    green: 0x2ecc71,
    yellow: 0x9ccc65
}



module.exports = {
    work(msg) {
        var date = Date.now()
        try {
            var lastworked = JSON.parse(fs.readFileSync(`./moneydata/lastworked/${msg.author.id}.json`, 'utf8'))
            var lastworked = parseInt(lastworked[msg.author.id])
        }
        catch(e) {
				var lastworked = parseInt(0)
        }
        var nextwork = lastworked + 120000
        if (date > nextwork) {
        	var plus = Math.floor(Math.random() * 1500 + 1)
        	try {
        		var opendata = JSON.parse(fs.readFileSync(`./moneydata/money/${msg.author.id}.json`, 'utf8'))
        		var moneyold = opendata[msg.author.id]
        	}
        	catch(e) {
        		var moneyold = parseInt(0)
        		console.log(e)
        	}
        	var moneynew = parseInt(moneyold) + plus
        	fs.writeFileSync(`./moneydata/money/${msg.author.id}.json`, `{\n    \"${msg.author.id}\": ${moneynew}\n}`)
        	var emb = new Discord.RichEmbed()
        		.setColor(COLORS.yellow)
        		.setTitle(`Du (${msg.author.username}) hast dir ${plus}${config.money} erarbeitet! Nun sind ${moneynew}${config.money} im System gespeichert!`)
        
        	msg.channel.send('', emb)
        	
        	fs.writeFileSync(`./moneydata/lastworked/${msg.author.id}.json`, `{\n    \"${msg.author.id}\": ${date}\n}`)
        }
        else {
        	var waittime = nextwork - date
        	console.log(waittime)
        	var wait = Math.floor(waittime / 60000)
        	var seconds = waittime / 1000
        	var minutes = wait * 60
        	var seconds = seconds - minutes
        	console.log(seconds)
        	var emb = new Discord.RichEmbed()
        		.setColor(COLORS.yellow)
        		.setTitle(`Du darfst nur alle 30 Minuten arbeiten. (Noch ${Math.floor(wait)} Minute/-n und ${Math.floor(seconds)} Sekunden)`)
        	msg.channel.send('', emb)
        	msg.delete()
        }
    }
}
