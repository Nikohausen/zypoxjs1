const Discord = require('discord.js')
const fs = require('fs')
const config = JSON.parse(fs.readFileSync('config.json', 'utf8'))

const COLORS = {
    red: 0xe74c3c,
    green: 0x2ecc71
}


module.exports = {
    stop(msg) {
        if (msg.content.startsWith(`${config.prefix}stop`)) {
            try {
                var Length = config.prefix.length + 5
                //passwort: 471847192847
                var arg1 = msg.content.slice(Length, 12 + Length)
                var arg2 = msg.content.slice(Length + 13, msg.content.length)
            }
            catch(e) {
                msg.channel.send('Failed stopping the Bot. Invalid arguments')
            }
            if (arg1 === '471847192847') {
                try{
                    if (arg2 === '') {
                        
                    }
                    else {
                        fs.appendFileSync('./stop/log.txt', `${msg.author.tag} hat den Bot gestoppt! (Angegebener Grund: ${arg2})\n`)
                    }
                }
                catch(e) {
                    if (arg2 === '') {
                        
                    }
                    else {
                        fs.writeFileSync('./stop/log.txt', `${msg.author.tag} hat den Bot gestoppt! (Angegebener Grund: ${arg2})\n`)
                    }
                }
                if (arg2 === '') {
                    msg.channel.send('Failed stopping the Bot. Invalid arguments: missing reason')
                }
                else {
                    error()
                }
            }
            else {
                msg.channel.send('Failed stopping the Bot. Invalid arguments: wrong passwort')
            }
        }
    }
}