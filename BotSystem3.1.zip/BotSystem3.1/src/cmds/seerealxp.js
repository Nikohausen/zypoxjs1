const Discord = require('discord.js')
const fs = require('fs')
const config = JSON.parse(fs.readFileSync('config.json', 'utf8'))

const COLORS = {
    red: 0xe74c3c,
    green: 0x2ecc71
}

module.exports = {
	seerealxp(msg) {
		try {
			var commandLength = config.prefix.length + 6
			var msgLength = msg.content.length
			var showUser = msg.content.slice(commandLength, msgLength)

			var seeuser = showUser.slice(6, showUser.length - 1)
			var allowed = JSON.parse(fs.readFileSync('allowed.json', 'utf8'))
			
			if (seeuser.startsWith('!')) {
				seeuser = seeuser.slice(1, seeuser.length)
			}

			var emb = new Discord.RichEmbed()
				.setColor(COLORS.green)

			if (msg.author.id in allowed) {
				try{
					var seeUserXp = JSON.parse(fs.readFileSync(`./data/${seeuser}.json`, 'utf8'))
						msg.delete()
						emb.setTitle(`Der angefragte Benutzer hat **${seeUserXp[seeuser]}** XP!`)
				}
				catch(e) {
					msg.delete()
					emb.setTitle(`Der angefragte Benutzer hat noch keine XP gesammelt`)
				}
			}
			else{
				emb.setTitle(`Du hast keine Berechtigung, dies zu tun.`)
			}
		}
		catch(e) {
			msg.channel.send(`Dies ist kein gültiger Benutzer\nBenutze den Syntax \`\`.see-xp @user\`\``)
		}
		msg.channel.send('', emb)
	}
}
