const Discord = require('discord.js')
const fs = require('fs')
const config = JSON.parse(fs.readFileSync('config.json', 'utf8'))
const allowed = JSON.parse(fs.readFileSync('allowed.json', 'utf8'))


const COLORS = {
    red: 0xe74c3c,
    green: 0x2ecc71
}

module.exports = {
	warnings(msg) {
		if (msg.author.id in allowed) {
			var prefixlength = config.prefix.length
			if (msg.content.length === prefixlength + 8) {
				var seeuser = msg.author.id
			}
			else {
				var commandLength = config.prefix.length + 9
				var msgLength = msg.content.length
				var showUser = msg.content.slice(commandLength, msgLength)

				var seeuser = showUser.slice(2, showUser.length - 1)
			
				if (seeuser.startsWith('!')) {
					seeuser = seeuser.slice(1, seeuser.length)
				}
				console.log(seeuser)
			}
			try {
				var opendata = JSON.parse(fs.readFileSync(`./warnings/${seeuser}.json`))
				var warned = opendata[seeuser]
			}
			catch(e) {
				var warned = 0
			}
			var emb = new Discord.RichEmbed()
				.setColor(COLORS.green)
				.setTitle(`Der angefragte Benutzer hat ${warned} Verwarnung/-en!`)
			if (warned > 3) {
				emb.setColor(COLORS.red)
			}
			msg.delete()
			msg.channel.send('', emb)
		}
	}
}
