const Discord = require('discord.js')
const fs = require('fs')
const config = JSON.parse(fs.readFileSync('config.json', 'utf8'))

const COLORS = {
    red: 0xe74c3c,
    green: 0x2ecc71
}

module.exports = {
	realxp(msg) {
		if (msg.author.id in config.blocked) {
		
		}
		else {
			var id = msg.author.id
			try {
				var opendata = JSON.parse(fs.readFileSync(`./data/${id}.json`, 'utf8'))
				var emb = new Discord.RichEmbed()
					.setTitle(`Du (${msg.author.username}) hast derzeitig **${opendata[id]}** XP!`)
					.setColor(COLORS.green)
				msg.channel.send('', emb)
				msg.delete()
			}
			catch(e) {
				var emb = new Discord.RichEmbed()
					.setTitle(`Du (${msg.author.username}) hast noch keine XP-Punkte gesammelt`)
					.setColor(COLORS.green)
				msg.channel.send('', emb)
				msg.delete()
			}
		}
	}
}
