const Discord = require('discord.js')
const fs = require('fs')
const config = JSON.parse(fs.readFileSync('config.json', 'utf8'))

const COLORS = {
    red: 0xe74c3c,
    green: 0x2ecc71
}

module.exports = {
    info(msg) {
        if (msg.author.id in config.blocked) {

        }
        else {
            try {
                var warnings = JSON.parse(fs.readFileSync(`./warnings/${msg.author.id}.json`, 'utf8'))
                var warned = warnings[msg.author.id]
            }
            catch(e) {
                var warned = 0
            }
            try {
                var opendata = JSON.parse(fs.readFileSync(`./data/${msg.author.id}.json`, 'utf8'))
                var yourxp = opendata[msg.author.id]
            }
            catch(e) {
                var yourxp = 0
                console.log(e)
            }
            var id = msg.author.id
            var thumb = msg.author.avatar
            var thumbnail = `https://cdn.discordapp.com/avatars/${id}/${thumb}.png?witdh=50&height=50`
            emb = new Discord.RichEmbed()
                .setTitle(` Info: ${msg.author.username}-`)
                .setDescription(`Alle Infos über dich und das Bot-System (${config.prefix}info)`)
                .addField(name='Warnungen', value="- Verwarnungen: 0\n(Info: Bei 5 verwarnungen wirst du gemuted. Antrag auf entmute unter http://forum.zypox.bplaced.net)")
                .setThumbnail(thumbnail)
                .setColor(COLORS.green)
            }
            if (warned > 3) {
                emb.setColor(COLORS.red)
            }
            if ('infinity' in opendata) {
                emb.addField(name='XP-System', value=`- Deine XP: Unendlich\n- Realxp: ${yourxp}`)
            }
            msg.channel.send('', emb)
    }
}
